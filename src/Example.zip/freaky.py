from tkinter import * 
from tkinter import messagebox 
  
root = Tk()

  
messagebox.showinfo("showinfo", "You feel freaky...") 
  
  
root.mainloop()  