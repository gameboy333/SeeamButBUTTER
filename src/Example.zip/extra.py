from tkinter import * 
from tkinter import messagebox 
  
root = Tk()

  
messagebox.showinfo("showinfo", "Extra script run") 
  
  
root.mainloop()  