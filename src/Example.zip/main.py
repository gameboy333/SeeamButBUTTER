from tkinter import * 
from tkinter import messagebox 
  
root = Tk()

  
messagebox.showinfo("showinfo", "Main script run") 
  
  
root.mainloop()  