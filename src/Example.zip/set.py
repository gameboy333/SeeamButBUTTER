from tkinter import * 
from tkinter import messagebox 
  
root = Tk()

  
messagebox.showinfo("showinfo", "theres no settings this is an example") 
  
  
root.mainloop()  